import plotly.express as px
import pandas as pd
import pathlib
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import dash_bootstrap_components as dbc
from datetime import datetime, date
from geopy.geocoders import Nominatim
from geopy.extra.rate_limiter import RateLimiter

from app import app
from app import server

from apps.predict_profit import get_prediction_api

# to set file path
PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../datasets").resolve()
dfp = pd.read_csv(DATA_PATH.joinpath("listings.csv"))

amenities_list = ['Long term stays allowed  ','Wifi  ','Hot water  ','Washer  ','Dryer  ','Hair dryer  ','Iron  ',
                'Shampoo  ','Essentials  ','Alarm  ','Kitchen  ','Dishes','Refrigerator','Microwave','Coffee','Fire extinguisher','Workspace','Park','TV']

# card page to show the Airbnb house features section, including neighbourhood, room_type, address, postcode, 
# Accommodates, Number of Baths, Number of Beds, house start date, Amenities
card_main = dbc.Card(
    [
        dbc.CardImg(src="/assets/predict.png", top=True, bottom=False,
                    title="Price predict", alt='Price predict'),
        html.Br(),
        dbc.CardBody(
            [
                html.H1("Price Optimization", className="card-title"),
                html.Br(),
                html.P(
                    "Please choose your Airbnb house features:",
                    className="card-subtitle",
                ),
                html.Br(),
                
                html.P(
                    "Region:",
                    className="card-text fw-bold fs-5",
                ),
                dcc.Dropdown(id='neighbourhood_choice', options=[{'label': yr, "value": yr} for yr in sorted(dfp.neighbourhood.unique())],
                             value='Downtown', clearable=False, style={"color": "#000000"}),
                html.Br(),
                
                html.P(
                "Address:",
                className="card-text fw-bold fs-5",
                ),
                html.P(
                "Please follow this format: \"Address line 1, City, State, Country\".",
                className="card-text",
                ),
                dcc.Input(id='address', value='', type='text', style={'width':'100%'}),
                html.H6(children=" ", id='warning_address', style={'color':'red'}),
                html.Br(),
                
                html.P(
                "Postcode:",
                className="card-text fw-bold fs-5",
                ),
                dcc.Input(id='postcode', value='', type='text', style={'width':'100%'}),
                html.Br(),
                html.Br(),
                
                html.P(
                    "House start date:",
                    className="card-text fw-bold fs-5",
                ),
                html.P(
                "Please enter/select the date you start renting your house",
                className="card-text",
                ),
                dcc.DatePickerSingle(
                    id='dt-pick-single', date = date.today()
                ),
                # dcc.Input(id='start_date', value='', type='text', style={'width':'100%'}),
                # html.H6(children=" ", id='warning_date', style={'color':'red'}),
                html.Br(),
                html.Br(),
                
                html.P(
                    "Room Type:",
                    className="card-text fw-bold fs-5",
                ),
                dcc.Dropdown(id='room_type_choice', options=[{'label': yr, "value": yr} for yr in sorted(dfp.room_type.unique())],
                             value='Entire home/apt', clearable=False, style={"color": "#000000"}),
                html.Br(),
                
                html.P(
                    "Accommodates:",
                    className="card-text fw-bold fs-5",
                ),
                dcc.Dropdown(id='accommodates_choice', options=[{'label': yr, "value": yr} for yr in range(1,21,1)],
                             value=1, clearable=False, style={"color": "#000000"}),
                html.Br(),
                
                html.P(
                    "Number of Baths:",
                    className="card-text fw-bold fs-5",
                ),
                dcc.Dropdown(id='bath_choice', options=[{'label': yr, "value": yr} for yr in range(1,11,1)],
                             value=1, clearable=False, style={"color": "#000000"}),
                html.Br(),
                
                html.P(
                    "Number of Beds:",
                    className="card-text fw-bold fs-5",
                ),
                dcc.Dropdown(id='beds_choice', options=[{'label': yr, "value": yr} for yr in range(1,21,1)],
                             value=1, clearable=False, style={"color": "#000000"}),
                html.Br(),
                
                html.P(
                    "Amenities:",
                    className="card-text fw-bold fs-5",
                ),
                dcc.Checklist(id='amenities',
                options=[{'label':str(b),'value':b} for b in amenities_list],
                value=[],
                inputStyle={"margin-right": "5px", 'cursor':'pointer'},
                labelStyle={'background':'#f8f9fa',   # style of the <label> that wraps the checkbox input and the option's label
                            'padding':'0.5rem 1rem',
                            'border-radius':'2rem',
                            },
                className="text-primary",
                #labelStyle = dict(display='one-line'),
            ),
                html.Br(),
                
                dbc.Button("Submit", id="submit_p", color="primary"),
                # dbc.CardLink("GirlsWhoCode", href="https://girlswhocode.com/", target="_blank"),
            ]
        ),
    ],
    color="dark",   # https://bootswatch.com/default/ for more card colors
    inverse=True,   # change color of text (black or white)
    outline=False,  # True = remove the block colors from the background and header
)

price_graph = dbc.Card(
    [
        dbc.CardBody([
            html.H3("Profit-Price Curve", className="card-title"),
            html.Br(),
            dcc.Graph(id='my_price_predict', figure={}),
        ])
    ], body=True, color="light", inverse=False, outline=False,
)

layout = html.Div([
    dbc.Row([dbc.Col(card_main, width=12)]), 
    html.Br(),
    dbc.Row([dbc.Col(price_graph, width=12)]),
])

@app.callback(
    [
        Output("my_price_predict", "figure"),
        Output("warning_address","children"),
        # Output("warning_date","children"),
    ],
    [
        State("neighbourhood_choice", "value"),
        State("address", "value"),
        State("postcode", "value"),
        State("dt-pick-single", "date"),
        State("room_type_choice", "value"),
        State("accommodates_choice", "value"),
        State("bath_choice", "value"),
        State("beds_choice", "value"),
        State("amenities", "value"),
    ],
    [
        Input("submit_p", "n_clicks")
    ]
    
)
def price_predict(nc,address,pc,sd,rt,ac,bath,bed,amenities,sub_n):
    warn_a = " "
    fig_null = px.scatter(pd.DataFrame({'price': [0], 'profit': [0]}), x="price", y="profit",
                     color="profit",
                     hover_name="profit").update_layout(title_x=0.5)
    if sub_n:
        date_diff = (date.today() - datetime.fromisoformat(sd).date()).days
        # date_diff = (date.today() - sd).days
        features_dict = {
            'address' : str(address),
            'postcode' : str(pc),
            'house_start_date' : date_diff,
            'neighbourhood_cleansed' : str(nc),
            'room_type' : str(rt),
            'accommodates' : int(ac),
            'baths' : int(bath),
            'beds' : int(bed),
            'amenities' : len(amenities)
        }
        df = get_prediction_api(features_dict)
        if len(df) > 0:
            fig = px.scatter(df, x="price", y="profit",
                        color="price",
                        hover_name="price").update_layout(title_x=0.5).update_traces(mode='lines+markers')
            return fig, warn_a
        else:
            warn_a = "Invalid address"
            return fig_null, warn_a
    # if sub_n == 0:
    else:
        return fig_null, warn_a

