# index.py is the entery page. To generate the entire website, just run "python3 index.py"

import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import dash_bootstrap_components as dbc
import plotly.express as px
import pandas as pd
import pathlib
import vaex

from app import app
from app import server
from apps import recommend, analysis, predict

# styling the sidebar
SIDEBAR_STYLE = {
    "position": "fixed",
    "top": 0,
    "left": 0,
    "bottom": 0,
    "width": "14rem",
    "padding": "2rem 1rem",
    "background-color": "#f8f9fa",
}

# padding for the page content
CONTENT_STYLE = {
    "margin-left": "15rem",
    "margin-right": "1rem",
    "padding": "2rem 1rem",
}

sidebar = html.Div(
    [
        html.H4("INT", className="display-4", style = {'fontSize': '2em'}),
        html.H2("Airbnb", className="display-4"),
        html.Hr(),
        html.P(
            "A tool to optimize your airbnb investment in Vancouver", className="text-muted"
        ),
        dbc.Nav(
            [
                dbc.NavLink("Data Analysis", href="/apps/analysis", active="exact"),
                dbc.NavLink("Price Optimation", href="/apps/predict", active="exact"),
                dbc.NavLink("Recommendation", href="/apps/recommend", active="exact"),
            ],
            vertical=True,
            pills=True,
            
        ),
    ],
    style=SIDEBAR_STYLE,
)

content = html.Div(id="page-content", children=[], style=CONTENT_STYLE)

app.layout = html.Div([
    dcc.Location(id="url"),
    sidebar,
    content
])


@app.callback(
    Output("page-content", "children"),
    [Input("url", "pathname")]
)
def render_page_content(pathname):
    if pathname == '/':
        return analysis.layout
    elif pathname == '/apps/analysis':
        return analysis.layout
    elif pathname == '/apps/recommend':
        return recommend.layout
    elif pathname == '/apps/predict':
        return predict.layout
    else:
        return "404"




if __name__=='__main__':
    app.run_server(debug=True)