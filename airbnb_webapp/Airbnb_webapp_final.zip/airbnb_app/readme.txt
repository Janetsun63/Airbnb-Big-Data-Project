To run the webapp, please make sure you have installed the librabries as below:
dash
dash_core_components
dash_html_components
dash_bootstrap_components
geopy
flask
pathlib
pandas
plotly
pyspark
vaem

index.py is the entry page of this website; please keep the folder structure as it is.

The commend to run the webapp is "spark-submit index.py"
