Pls don't change the folder structure; index.py is the entry page to the website
To run the code, use "python3 index.py"
Libs need to be installed in advance:
plotly
dash
dash_core_components
dash_html_components
dash_bootstrap_components