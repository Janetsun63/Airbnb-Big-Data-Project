import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output, State
import dash_bootstrap_components as dbc
import plotly.express as px
import pandas as pd
import pathlib
import dash

from app import app
from app import server

PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../datasets").resolve()

# to read listings.csv file to generate map with full lists
dfar = pd.read_csv(DATA_PATH.joinpath("listings.csv"))
dfar1 = dfar.where(dfar['price'] < 1000)

# to read recommendation results file to show the recommendation results
dfr = pd.read_csv(DATA_PATH.joinpath("recommend_10.csv"))

# this token is to access mapbox
token = "pk.eyJ1IjoibHNhMTA4IiwiYSI6ImNrd255ZWE3YzI2MTEyd2w1OTQ5cmwzczkifQ.LkF9vfubUb2-aYHYrTssEg"

# to generate the main card showing the user id input
card_main = dbc.Card(
    [
        dbc.CardImg(src="../assets/recommend.png", top=True, bottom=False,
                    title="Recommend", alt='recommend'),
        html.Br(),
        dbc.CardBody(
            [
                html.H1("Recommendation", className="card-title"),
                html.Br(),
                html.P(
                    "We will recommend the best ten Airbnb posts according to your prior reviews.",
                    className="card-subtitle",
                ),
                html.Br(),
                html.P(
                    "Please enter your User ID:",
                    className="card-text",
                ),
                dcc.Input(id='my_userid', value="", type='text'),
                html.H6(children=" ", id='warning', style={'color':'red'}),
                html.Br(),
                dbc.Button("Submit", color="primary", id="submit_r", n_clicks=0),
                
                # dbc.CardLink("GirlsWhoCode", href="https://girlswhocode.com/", target="_blank"),
            ]
        ),
    ],
    color="dark",   # https://bootswatch.com/default/ for more card colors
    inverse=True,   # change color of text (black or white)
    outline=False,  # True = remove the block colors from the background and header
)

# to generate recommendation results in the mapbox
card_graph = dbc.Card(
    [
        dbc.CardBody([
            html.H3("Recommendation Results", className="card-title"),
            dcc.Graph(id='my_recommend_map', figure={}), 
        ])
    ], body=True, color="light", inverse=False, outline=False,
)

# to generate filters card of neighbourhood, room_type, and price range
card_filter = dbc.Card(
    [
        dbc.CardBody([
            html.H4("Recommendation Filters", className="card-title"),
            html.P(
                "Price Max:",
                className="card-text fw-bold",
            ),
            dcc.Input(id='max_price', value=1000.0, type='number',step=50),
            html.Br(),
            html.Br(),
            html.P(
                "Price Min:",
                className="card-text fw-bold",
            ),
            dcc.Input(id='min_price', value=0.0, type='number',step=50),
            html.Br(),
            html.Br(),
            html.P(
                "Room Type:",
                className="card-text fw-bold",
            ),
            dcc.Checklist(id='room_type_choice', 
            options=[{'label': yr, "value": yr} for yr in sorted(dfr.room_type.unique())],
            value=[b for b in dfr.room_type.unique()], 
            inputStyle={"margin-right": "5px", 'cursor':'pointer'},
            labelStyle=dict(display='block'),
            ),
            html.Br(),
            html.P(
                    "Neighbourhood:",
                    className="card-text fw-bold",
                ),
            dcc.Checklist(id='neighbourhood_choice', 
            options=[{'label': yr, "value": yr} for yr in sorted(dfr.neighbourhood.unique())],
            value=[b for b in dfr.neighbourhood.unique()], 
            inputStyle={"margin-right": "5px", 'cursor':'pointer'},
            labelStyle=dict(display='block'),
            ),
            
        ])
    ]
)

# to design the layout the recommendation page
layout = html.Div([
    dbc.Row([dbc.Col(card_main, width=12)]), 
    html.Br(),
    dbc.Row([dbc.Col(card_graph, width=9),dbc.Col(card_filter, width=3)]),
])

# callbacks of the "user id - recommendation results" function and filters function
@app.callback(
    [
        Output("my_recommend_map", "figure"),
        Output("warning","children"),
    ],
    [
        State("my_userid", "value"),
    ],
    [
        Input("submit_r", "n_clicks"),
        Input("neighbourhood_choice", "value"),
        Input("room_type_choice", "value"),
        Input("max_price", "value"),
        Input("min_price", "value"),
    ],
    
)
def update_graph(userid,submit,neighbour,room,maxp,minp): 
    warn = " "
    if len(userid) > 0:
        dfr1 = dfr[dfr['reviewer_id']==int(userid)]
        if (submit > 0) & (len(dfr1) > 0):
            dfr2 = dfr1[dfr1['neighbourhood'].isin(neighbour)]
            dfr3 = dfr2[dfr2['room_type'].isin(room)]
            dfr4 = dfr3.where((dfr3['price'] > float(minp)) & (dfr3['price'] < float(maxp)))

            fig = px.scatter_mapbox(dfr4, lat="latitude", lon="longitude",color="price", hover_name="listing_id", 
                                hover_data=["price","rating","accommodates","neighbourhood","room_type"],
                                color_continuous_scale=px.colors.cyclical.IceFire, zoom=11, height=500)
            fig.update_layout(mapbox_accesstoken=token)
            fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})

        if (submit > 0) & (len(dfr1) == 0):
            warn = 'Invalid User ID'
            dfar2 = dfar1[dfar1['neighbourhood'].isin(neighbour)]
            dfar3 = dfar2[dfar2['room_type'].isin(room)]
            dfar4 = dfar3.where((dfar3['price'] > float(minp)) & (dfar3['price'] < float(maxp)))
            fig = px.scatter_mapbox(dfar4, lat="latitude", lon="longitude",color="price", hover_name="id", 
                                hover_data=["price","accommodates","neighbourhood","room_type"],
                                color_continuous_scale=px.colors.cyclical.IceFire, zoom=11, height=500)
            fig.update_layout(mapbox_accesstoken=token)
            fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})
        return fig, warn
    
    if len(userid) == 0:
        dfar2 = dfar1[dfar1['neighbourhood'].isin(neighbour)]
        dfar3 = dfar2[dfar2['room_type'].isin(room)]
        dfar4 = dfar3.where((dfar3['price'] > float(minp)) & (dfar3['price'] < float(maxp)))
        fig = px.scatter_mapbox(dfar4, lat="latitude", lon="longitude",color="price", hover_name="id", 
                                hover_data=["price","accommodates","neighbourhood","room_type"],
                                color_continuous_scale=px.colors.cyclical.IceFire, zoom=11, height=500)
        fig.update_layout(mapbox_accesstoken=token)
        fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})
        return fig, warn
