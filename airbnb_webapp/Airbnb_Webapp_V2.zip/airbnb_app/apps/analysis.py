from flask import sessions
import plotly.express as px
import pandas as pd
import pathlib
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import dash_bootstrap_components as dbc

from app import app
from app import server

# this token is to access mapbox
token = "pk.eyJ1IjoibHNhMTA4IiwiYSI6ImNrd255ZWE3YzI2MTEyd2w1OTQ5cmwzczkifQ.LkF9vfubUb2-aYHYrTssEg"

# to read data
PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../datasets").resolve()
dfa = pd.read_csv(DATA_PATH.joinpath("listings.csv"))
dfa1 = dfa.where(dfa['price'] < 1000) # delete price over 1000

dfm = pd.read_csv(DATA_PATH.joinpath("monthly_price.csv")) # monthly price dataset

dfwh = pd.read_csv(DATA_PATH.joinpath("weather.csv")) # weather dataset

features = ['neighbourhood','room_type','accommodates','baths','beds','amenities'] # features used in price & occupancy analysis

# to generate neighbourhood checklist filter
card_neigh = dbc.Card(
    [
        dbc.CardBody([
            html.H4("Neighbourhood", className="card-title"),
            dcc.Checklist(id='neighbourhood',
                options=[{'label':str(b),'value':b} for b in sorted(dfa['neighbourhood'].unique())],
                value=[b for b in sorted(dfa['neighbourhood'].unique())],
                labelStyle = dict(display='block'),
            ),
        ])
    ], color="light", inverse=False, outline=False,
)

# to generate map graph
card_graph1 = dbc.Card(
    [
        dbc.CardBody([
            html.H3("Vancouver Airbnb distribution", className="card-title"),
            dcc.Graph(id='my_map', figure={}), 
        ])
    ], body=True, color="dark", inverse=True, outline=False,
)

# to generate price analysis graph
card_graph2 = dbc.Card([
        dbc.CardBody([
            html.H3("Price Analysis", className="card-title"),
            html.P(
                    "Choose the feature you would like to see on the bubble chart.",
                    className="card-text",
                    ),
            dcc.Dropdown(id='user_choice2', options=[{'label': yr, "value": yr} for yr in features],
                                value='neighbourhood', clearable=False, style={"color": "#000000"}),
            html.Br(),
            dcc.Graph(id='my_price_analysis', figure={}),
        ])
    ], body=True, color="warning", inverse=True, outline=False,
)

# to generate occupancy analysis graph
card_graph3 = dbc.Card([
        dbc.CardBody([
            html.H3("Occupancy Analysis", className="card-title"),
            html.P(
                    "Choose the feature you would like to see on the bubble chart.",
                    className="card-text",
                    ),
            dcc.Dropdown(id='user_choice3', options=[{'label': yr, "value": yr} for yr in features],
                                value='neighbourhood', clearable=False, style={"color": "#000000"}),
            html.Br(),
            dcc.Graph(id='my_occupancy_analysis', figure={}),
        ])
    ], body=True, color="dark", inverse=True, outline=False,
)

# to generate monthly price graph
fig_mp = px.scatter(dfm, x="month", y="price",
                     size="price", color="price",
                     hover_name="price", size_max=10).update_layout(title_x=0.5).update_traces(mode='lines+markers')

card_graph4 = dbc.Card([
        dbc.CardBody([
            html.H3("Monthly Price", className="card-title"),
            html.Br(),
            dcc.Graph(id='my_monthly_price', figure=fig_mp),
        ])
    ], body=True, color="dark", inverse=True, outline=False,
)

# to generate monthly weather graph

weather_features = ['rain','temperature','max_tem','min_tem']

fig_wh = px.scatter(dfm, x="month", y="price",
                     size="price", color="price",
                     hover_name="price", size_max=10).update_layout(title_x=0.5)

card_graph5 = dbc.Card([
        dbc.CardBody([
            html.H3("Monthly Weather", className="card-title"),
            dcc.RadioItems(id='weather_choice', options=[{'label': yr, "value": yr} for yr in weather_features],
                         value='rain', style={"color": "#000000"},
                         inputStyle={"margin-right": "5px", 'cursor':'pointer'},
                         labelStyle={'background':'#f8f9fa',   # style of the <label> that wraps the checkbox input and the option's label
                            'padding':'0.5rem 0.5rem',
                            'border-radius':'2rem',
                        },
                        className="text-primary",
                            ),
            html.Br(),
            dcc.Graph(id='my_monthly_weather', figure={}),
        ])
    ], body=True, color="warning", inverse=True, outline=False,
)

# to insert vancouver_choropleth_map.html, which is the average price map by region
HTML_PATH = PATH.joinpath("../assets").resolve()
card_geo = dbc.Card(
    [
        dbc.CardBody([
            html.H3("Average Price Distribution by Neighbourhood", className="card-title"),
            html.Iframe(id='my_geo_map', srcDoc = open(HTML_PATH.joinpath("vancouver_choropleth_map.html"),'r').read(), width='100%',height='450'), 
        ])
    ], body=True, color="light", inverse=False, outline=False,
)

# to define the layout of the data analysis page
layout = html.Div([
    dbc.Row([dbc.Col(card_graph1, width=9),
            dbc.Col(card_neigh, width=3)], justify="around"),  # justify="start", "center", "end", "between", "around"
    html.Br(),
    dbc.Row([dbc.Col(card_geo, width=12)]),
    html.Br(),
    dbc.Row([dbc.Col(card_graph2, width=6),
            dbc.Col(card_graph3, width=6)], justify="around"),
    html.Br(),
    dbc.Row([dbc.Col(card_graph4, width=6),
            dbc.Col(card_graph5, width=6)], justify="around"),
])

# to define callbacks of the neighbourhood filter
@app.callback(
    Output("my_map", "figure"),
    [Input("neighbourhood", "value")]
)
def update_graph(value):
    fig = px.scatter_mapbox(dfa1.query("neighbourhood=={}".format(str(value))), lat="latitude", lon="longitude",color="price", hover_name="id", 
                        hover_data=["room_type","accommodates","baths","num_bus_2km", "num_subway_2km","num_shop_2km","num_restaurant_2km"],
                        color_continuous_scale=px.colors.cyclical.IceFire, zoom=11, height=450)
    fig.update_layout(mapbox_accesstoken=token)
    fig.update_layout(margin={"r":0,"t":0,"l":0,"b":0})
    return fig

# to define callbacks of the features filter in the price analysis
@app.callback(
    Output("my_price_analysis", "figure"),
    [Input("user_choice2", "value")]
)
def update_graph(value):
    fig = px.scatter(dfa.groupby([value])['price'].mean().reset_index(), x=value, y="price",
                     size="price", color="price",
                     hover_name="price", size_max=10).update_layout(title_x=0.5)
    return fig

# to define callbacks of the features filter in the occupancy analysis
@app.callback(
    Output("my_occupancy_analysis", "figure"),
    [Input("user_choice3", "value")]
)
def update_graph(value):
    fig = px.scatter(dfa.groupby([value])['occupancy'].mean().reset_index(), x=value, y="occupancy",
                     size="occupancy", color="occupancy",
                     hover_name="occupancy", size_max=10).update_layout(title_x=0.5)
    return fig

# to define callbacks of the features filter in the monthly weather graph
@app.callback(
    Output("my_monthly_weather", "figure"),
    [Input("weather_choice", "value")]
)
def update_graph(value):
    fig = px.scatter(dfwh, x='month', y=value,
                     size=value, color=value,
                     hover_name=value, size_max=10).update_layout(title_x=0.5).update_traces(mode='lines+markers')
    return fig



