import plotly.express as px
import pandas as pd
import pathlib
import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output
import dash_bootstrap_components as dbc

from app import app
from app import server

# to set file path
PATH = pathlib.Path(__file__).parent
DATA_PATH = PATH.joinpath("../datasets").resolve()
dfp = pd.read_csv(DATA_PATH.joinpath("listings.csv"))

amenities_list = ['Long term stays allowed  ','Wifi  ','Hot water  ','Washer  ','Dryer  ','Hair dryer  ','Iron  ',
                'Shampoo  ','Essentials  ','Alarm  ','Kitchen  ','dishes','refrigerator','microwave','coffee','fire extinguisher','workspace','park','tv']

# card page to show the Airbnb house features section, including neighbourhood, room_type, address, postcode, 
# Accommodates, Number of Baths, Number of Beds, house start date, Amenities
card_main = dbc.Card(
    [
        dbc.CardImg(src="/assets/predict.png", top=True, bottom=False,
                    title="Price predict", alt='Price predict'),
        html.Br(),
        dbc.CardBody(
            [
                html.H1("Price Optimization", className="card-title"),
                html.Br(),
                html.P(
                    "Please choose your Airbnb house features:",
                    className="card-subtitle",
                ),
                html.Br(),
                
                html.P(
                    "Neighbourhood:",
                    className="card-text fw-bold fs-5",
                ),
                dcc.Dropdown(id='neighbourhood_choice', options=[{'label': yr, "value": yr} for yr in sorted(dfp.neighbourhood.unique())],
                             value='Downtown', clearable=False, style={"color": "#000000"}),
                html.Br(),
                
                html.P(
                "Address:",
                className="card-text fw-bold fs-5",
                ),
                html.P(
                "Please follow this format: \"Address line 1, City, State, Country\".",
                className="card-text",
                ),
                dcc.Input(id='address', value='', type='text', style={'width':'100%'}),
                html.Br(),
                html.Br(),
                
                html.P(
                "Postcode:",
                className="card-text fw-bold fs-5",
                ),
                dcc.Input(id='postcode', value='', type='text', style={'width':'100%'}),
                html.Br(),
                html.Br(),
                
                html.P(
                    "House start date:",
                    className="card-text fw-bold fs-5",
                ),
                html.P(
                "Please enter the date you start renting your house and follow this format: \"DD\MM\YYYY\".",
                className="card-text",
                ),
                dcc.Input(id='address', value='', type='text', style={'width':'100%'}),
                html.Br(),
                html.Br(),
                
                html.P(
                    "Room Type:",
                    className="card-text fw-bold fs-5",
                ),
                dcc.Dropdown(id='room_type_choice', options=[{'label': yr, "value": yr} for yr in sorted(dfp.room_type.unique())],
                             value='Entire home/apt', clearable=False, style={"color": "#000000"}),
                html.Br(),
                
                html.P(
                    "Accommodates:",
                    className="card-text fw-bold fs-5",
                ),
                dcc.Dropdown(id='accommodates_choice', options=[{'label': yr, "value": yr} for yr in range(1,21,1)],
                             value=1, clearable=False, style={"color": "#000000"}),
                html.Br(),
                
                html.P(
                    "Number of Baths:",
                    className="card-text fw-bold fs-5",
                ),
                dcc.Dropdown(id='bath_choice', options=[{'label': yr, "value": yr} for yr in range(1,11,1)],
                             value=1, clearable=False, style={"color": "#000000"}),
                html.Br(),
                
                html.P(
                    "Number of Beds:",
                    className="card-text fw-bold fs-5",
                ),
                dcc.Dropdown(id='beds_choice', options=[{'label': yr, "value": yr} for yr in range(1,21,1)],
                             value=1, clearable=False, style={"color": "#000000"}),
                html.Br(),
                
                html.P(
                    "Amenities:",
                    className="card-text fw-bold fs-5",
                ),
                dcc.Checklist(id='amenities',
                options=[{'label':str(b),'value':b} for b in amenities_list],
                value=[],
                inputStyle={"margin-right": "5px", 'cursor':'pointer'},
                labelStyle={'background':'#f8f9fa',   # style of the <label> that wraps the checkbox input and the option's label
                            'padding':'0.5rem 1rem',
                            'border-radius':'2rem',
                            },
                className="text-primary",
                #labelStyle = dict(display='one-line'),
            ),
                html.Br(),
                
                dbc.Button("Submit", color="primary"),
                # dbc.CardLink("GirlsWhoCode", href="https://girlswhocode.com/", target="_blank"),
            ]
        ),
    ],
    color="dark",   # https://bootswatch.com/default/ for more card colors
    inverse=True,   # change color of text (black or white)
    outline=False,  # True = remove the block colors from the background and header
)

layout = html.Div([
    dbc.Row([dbc.Col(card_main, width=12)]), 
    # html.Br(),
    # dbc.Row([dbc.Col(card_graph2, width=6),
    #         dbc.Col(card_graph3, width=6)], justify="around"),
])