Pls don't change the folder structure; index.py is the entry page to the website
To run the code, use "python3 index.py"